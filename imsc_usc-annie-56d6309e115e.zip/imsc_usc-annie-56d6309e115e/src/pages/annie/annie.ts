import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'annie',
  templateUrl: 'annie.html'
})
export class AnniePage {

  constructor(public navCtrl: NavController) {

  }

  

}
